sudo apt-get install shutter
