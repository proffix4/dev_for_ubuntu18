# shutter_for_ubuntu18.04

Крутой создатель скриншотов для Ubuntu 18.04

![srcreenshot](shutter.png)
